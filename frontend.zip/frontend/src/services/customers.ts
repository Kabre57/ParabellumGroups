export * from '@/shared/api/services/customers';
