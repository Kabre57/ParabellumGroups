export * from '@/shared/api/services/technical';
